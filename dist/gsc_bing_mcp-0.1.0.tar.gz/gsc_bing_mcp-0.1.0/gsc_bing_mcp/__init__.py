"""
gsc-bing-mcp: MCP server for Google Search Console and Bing Webmaster Tools.
Uses Chrome browser session cookies for Google (no API key needed)
and Bing Webmaster API key for Bing.
"""

__version__ = "0.1.0"
