# Extractors package: cookie extraction and auth header generation
